# Axel Portfolio

Portfolio frontend built with React, TypeScript, Vite, Framer Motion, Lucide, and Supabase client.

## Run locally
1. Install Node.js 20+
2. `npm install`
3. `npm run dev`

## Supabase setup
Create a Supabase project. Create an admin user in Authentication. Apply `supabase.sql` in SQL Editor. Add `.env` with:
```
VITE_SUPABASE_URL=your_project_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```
Never put the service-role key in frontend code.

## Current state
This package is a working visual frontend scaffold. Feedback form is intentionally in demo mode until Supabase environment variables and schema are connected. Admin route is a placeholder and should be implemented with Supabase Auth + server/database authorization before production.
