-- Supabase schema starter. Apply in Supabase SQL editor.
create table if not exists public.feedback (
 id uuid primary key default gen_random_uuid(),
 name text,
 message text not null check (char_length(message) <= 3000),
 created_at timestamptz not null default now(),
 status text not null default 'unread' check (status in ('unread','read'))
);
create table if not exists public.projects (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text,
 category text,
 image_url text,
 website_url text,
 published boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.analytics (
 id uuid primary key default gen_random_uuid(),
 event_type text not null check (event_type in ('page_view','project_click','whatsapp_click','service_click')),
 page text,
 project_id uuid references public.projects(id) on delete set null,
 created_at timestamptz not null default now()
);
alter table public.feedback enable row level security;
alter table public.projects enable row level security;
alter table public.analytics enable row level security;

-- Public may submit feedback, but cannot read/update/delete it.
create policy "public submit feedback" on public.feedback for insert to anon, authenticated with check (true);
-- Public can view only published projects.
create policy "public read published projects" on public.projects for select to anon, authenticated using (published = true);
-- Admin policies should be added after creating an admin-role mechanism.
-- Do not rely on frontend route guards alone. Prefer custom claims or a private admin table
-- with policies checking auth.uid() against the authorized admin IDs.
-- Analytics inserts require a server/Edge Function validation layer in production.
